package constants;

public class DatabaseConstants {
    public static final String CONNECTION_URL = "jdbc:sqlite:quiz.db";
    public static final String DRIVER_CLASS = "org.sqlite.JDBC";
}
