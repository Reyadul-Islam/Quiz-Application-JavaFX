package listeners;

public interface AttempedQuizItemClickListener {
    void itemClicked(Integer nof , Integer noa);
}
